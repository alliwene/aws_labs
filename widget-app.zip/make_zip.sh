# Run from widget-app directory
zip -r ../widget-app.zip *
